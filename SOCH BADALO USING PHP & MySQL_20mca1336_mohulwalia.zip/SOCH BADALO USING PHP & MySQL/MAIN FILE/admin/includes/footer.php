 <footer>
            <p>SOCH BADALO</p>
        </footer>